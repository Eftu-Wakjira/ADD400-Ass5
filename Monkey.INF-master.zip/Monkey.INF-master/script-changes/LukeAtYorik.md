LUKE 

Alas, poor stormtrooper, I knew ye not,
Yet have I ta’en both uniform and life
From thee. What manner of a man wert thou?
A man of inf’nite jest or cruelty?
A man with helpmate and with children too?
A man who hath his Empire serv’d with pride?