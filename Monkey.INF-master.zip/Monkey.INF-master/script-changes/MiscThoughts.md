I'm thinking we need more space battles for this play.  

It's all well and good to have a few sword fights here

and there, but spaceship battles!  Come on!  You have

to agree there is great value in the flash of blasters,

of laser swords, the explosions of great vessels of

the void that get's one's spirits roused!

Fantasy has been played out.  More space stuffs!

