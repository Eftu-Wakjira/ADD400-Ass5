PROLOGUE

Outer Space.

ENTER Chorus.

CHORUS
It is a period of civil war. 
The spaceships of the rebels, striking swift
From base unseen, have gain’d a vict’ry o’er
The cruel Galactic Empire, now adrift.
Amidst the battle, rebel spies prevail’d
And stole the plans to a space station vast,
Whose pow’rful beams will later be unveil’d
And crush a planet: ’tis the DEATH STAR blast.
Pursu’d by agents sinister and cold,
Now Princess Leia to her home doth flee,
Deliv’ring plans and a new hope they hold:
Of bringing freedom to the galaxy.
In time so long ago begins our play,
In star-crossed galaxy far, far away.

EXIT Chorus.
